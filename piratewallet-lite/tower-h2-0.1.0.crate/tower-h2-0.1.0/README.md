# tower-h2

Tower `Service` abstractions for HTTP/2 and Rust.

[![Build Status](https://travis-ci.org/tower-rs/tower-h2.svg?branch=master)](https://travis-ci.org/tower-rs/tower-h2)

More information about this crate can be found in the [crate documentation][dox]

[dox]: https://tower-rs.github.io/tower-h2/tower_h2

At some point, this will be folded into Hyper.

## License

This project is licensed under the [MIT license](LICENSE).

### Contribution

Unless you explicitly state otherwise, any contribution intentionally submitted
for inclusion in `tower-h2` by you, shall be licensed as MIT, without any
additional terms or conditions.
