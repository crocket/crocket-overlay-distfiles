pub(crate) mod note_encryption;
