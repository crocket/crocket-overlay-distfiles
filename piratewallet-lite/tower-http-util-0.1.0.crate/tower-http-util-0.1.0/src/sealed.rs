pub trait Sealed<B> {}
